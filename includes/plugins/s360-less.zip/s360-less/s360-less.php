<?php
/*
	Plugin Name: S360 LESS
	Plugin URI: http://sota360.ro
	Description: This is a WordPress Plugin licensed with GPL 2 licence. Plugin is designed by SOTA360 Digital Agency. Plugin is used to compile LESS to CSS in projects with fast development cycle.
	Version: 0.0.1
	Author: SOTA360
	Author URI: http://sota360.ro
	License: GNU General Public License v2.0
	License URI: http://www.gnu.org/licenses/gpl-2.0.html
	Text Domain: cdn-less
	Domain Path: /languages/
*/

	/*
		HOW TO USE:

		// FRONT END
		add_action( 's360_less_scripts', function( $less ){

			// RELATIVE TO THEME DIRECTORY
	        $less -> add( '/public/less/styles.less', '/public/css/styles.css' );
	        $less -> add( '/public/less/docs.less', '/public/css/docs.css' );

	        $less -> compile();

	    }, 10 );

		// BACK END
		add_action( 's360_less_admin_scripts', function( $less ){

			// RELATIVE TO THEME DIRECTORY
	        $less -> add( '/public/less/styles.less', '/public/css/styles.css' );
	        $less -> add( '/public/less/docs.less', '/public/css/docs.css' );

	        $less -> compile();

	    }, 10 );

	*/

	// If this file is called directly, abort.
	if ( ! defined( 'WPINC' ) ) {
		die;
	}

    function s360_less_uri(){

        return rtrim( plugin_dir_url( __FILE__ ), '/' );
    }

    if( !class_exists( 's360_less' ) ){

        class s360_less{

            private $side = 'public';
            private $sources = [];

            public function __construct( $side ){

                if( in_array( $side, [ 'admin', 'public' ] ) )
                    $this -> side = $side;

                add_action( 'wp_ajax_s360_less_css_file' , [ $this, 'ajax_css_file' ] );
                add_action( 'wp_ajax_nopriv_s360_less_css_file' , [ $this, 'ajax_css_file' ] );

            }

            public function ajax_css_file(){

                $css    = isset($_POST['css']) ? $_POST['css'] : null;
                $path   = isset($_POST['path']) ? $_POST['path'] : null;

                $info   = pathinfo( $path );

                if( !is_dir( $info['dirname'] ) )
                    mkdir( $info['dirname'], 755, true );

                $file   = basename( $path );
                $name   = sanitize_file_name( $file );

                if( empty($name) ){
                    echo json_encode([
                        'type'      => 'error',
                        'message'   => sprintf(esc_html__( 'Invalid file name: %1$s', 's360-less' ), $file )
                    ]);
                    exit();
                }

                if( $handler = fopen( $info['dirname'] . '/' . $name, "w" ) ){

                    fwrite( $handler, $css );
                    fclose( $handler );

                    echo json_encode([
                        'type'      => 'success',
                        'message'   => sprintf(esc_html__( 'Success: %1$s', 's360-less' ), str_replace( get_stylesheet_directory(), '', $info['dirname'] ) . '/' . $name )
                    ]);
                }
                else{
                    echo json_encode([
                        'type'      => 'error',
                        'message'   => sprintf(esc_html__( 'Unable to open file: %1$s', 's360-less' ), str_replace( get_stylesheet_directory(), '', $info['dirname'] ) . '/' . $name )
                    ]);
                }

                exit();
            }

            public function add( $less, $css ){

				$host = $_SERVER['HTTP_HOST'] . '/';
				$prot = isset($_SERVER['HTTPS']) && 'on' == esc_attr($_SERVER['HTTPS']) ? 'https://' : 'http://';

                $this -> sources[] = [
                    'less'  => get_stylesheet_directory_uri() . $less,
                    'css'   => get_stylesheet_directory() . $css,
                    'id'    => sanitize_title( str_replace( [ $prot . $host , '.less' ], '', get_stylesheet_directory_uri() . $less ) )
                ];
            }

            public function compile(){

                if( $this -> side == 'public' ){
                    add_action( 'wp_footer', function(){
                        foreach ( $this -> sources as $source ) {
                            echo '<link rel="stylesheet/less" type="text/css" href="' . esc_url($source['less']) . '"/>';
                        }
                    }, 10);

                    add_action( 'wp_enqueue_scripts', function(){

                        wp_register_script( 'cdn-less', '//cdn.jsdelivr.net/npm/less@4.1.1', null, null, true );
                        wp_enqueue_script( 'cdn-less' );

                        wp_register_script( 's360-less-scripts', s360_less_uri() . '/scripts.js', [ 'jquery' ] , null, true );
                        wp_localize_script( 's360-less-scripts', 's360_less',
                            [
                                'ajaxurl'   => admin_url( 'admin-ajax.php' ),
                                'sources'   => $this -> sources
                            ]
                        );
                        wp_enqueue_script( 's360-less-scripts' );

                    }, 100);
                }

                if( $this -> side == 'admin' ){
                    add_action( 'admin_footer', function(){

                        foreach ( $this -> sources as $source ) {
                            echo '<link rel="stylesheet/less" type="text/css" href="' . esc_url($source['less']) . '"/>';
                        }

                    }, 10);

                    add_action( 'admin_enqueue_scripts', function(){

                        wp_register_script( 'cdn-less', '//cdn.jsdelivr.net/npm/less@4.1.1', null, null, true );
                        wp_enqueue_script( 'cdn-less' );

                        wp_register_script( 's360-less-scripts', s360_less_uri() . '/scripts.js', [ 'jquery' ] , null, true );
                        wp_localize_script( 's360-less-scripts', 's360_less',
                            [
                                'ajaxurl'   => admin_url( 'admin-ajax.php' ),
                                'sources'   => $this -> sources
                            ]
                        );
                        wp_enqueue_script( 's360-less-scripts' );
                    }, 100);
                }
            }
        }

        add_action( 'after_setup_theme', function(){
			if( is_admin() ){
				do_action( 's360_less_admin_scripts', $less = new s360_less( 'admin' ) );
			}
			else{
				do_action( 's360_less_scripts', $less = new s360_less( 'public' ) );
			}
        }, 0);
    }
?>
