(function($) {

    var observers = [];

    $.event.special.domNodeInserted = {

        setup: function setup(data, namespaces) {
            var observer = new MutationObserver(checkObservers);

            observers.push([this, observer, []]);
        },
        teardown: function teardown(namespaces) {
            var obs = getObserverData(this);

            obs[1].disconnect();

            observers = $.grep(observers, function(item) {
                return item !== obs;
            });
        },

        remove: function remove(handleObj) {
            var obs = getObserverData(this);

            obs[2] = obs[2].filter(function(event) {
                return event[0] !== handleObj.selector && event[1] !== handleObj.handler;
            });
        },

        add: function add(handleObj) {
            var obs = getObserverData(this);

            var opts = $.extend({}, {
                childList: true,
                subtree: true
            }, handleObj.data);

            obs[1].observe(this, opts);
            obs[2].push([handleObj.selector, handleObj.handler]);
        }
    };

    function getObserverData(element) {
        var $el = $(element);

        return $.grep(observers, function(item) {
            return $el.is(item[0]);
        })[0];
    }

    function checkObservers(records, observer) {
        var obs = $.grep(observers, function(item) {
            return item[1] === observer;
        })[0];

        var triggers = obs[2];

        var changes = [];

        records.forEach(function(record) {
            if (record.type === 'attributes') {
                if (changes.indexOf(record.target) === -1) {
                    changes.push(record.target);
                }

                return;
            }

            $(record.addedNodes).toArray().forEach(function(el) {
                if (changes.indexOf(el) === -1) {
                    changes.push(el);
                }
            })
        });

        triggers.forEach(function checkTrigger(item) {
            changes.forEach(function(el) {
                var $el = $(el);

                if ($el.is(item[0])) {
                    $el.trigger('domNodeInserted');
                }
            });
        });
    }
})(jQuery);

jQuery(document).ready(function(){

    console.log( " -- S360 Less -- " );

    var ajaxurl = s360_less.ajaxurl;
    s360_less.sources.forEach(function( source, index ){

        console.log( source );

        jQuery(document.body).on("domNodeInserted", "style#less\\:" + source.id, function(){
            if( jQuery(this).length ){
                var css = jQuery(this)[0].innerHTML;

                console.log( css );

                jQuery.post( ajaxurl, {
                	'action'   : 's360_less_css_file',
                	'css'      : encodeURI(css),
                	'path'     : source.css
                }, function( result ){
                    var res = JSON.parse( result );
                    console.log(res.message);
                });
            }
        });
    });
});
